# Task: Re-render a "happy accident" YuE2 song, fixing only two mispronounced words (token-level surgery)

## Context
Repo: `arabmaqamrock` (YuE2-3B + my LoRA through **audio.cpp / `audiocpp_cli`**, BF16 GGUF,
`cot=off`, no ABC score), driven by `generate.py` / `run_one.sh`.
Runtime docs: `docs/models/yue2.md` and `examples/yue2_style_change/` in
https://github.com/0xShug0/audio.cpp (clone it; read both fully first; also skim `app/server/README.md`).

The song is track **`02-استيداع-قمر-بغداد-ولوعة-الوداع-B`** (take 0, idx 5, seed 1712905618) from the batch dir
`out/20261018-162827_batch_12_variants_backing_vocals/` (Colab, Tesla T4). I consider it a "happy accident":
arrangement, melody, voice and mix are exactly what I want. The lyrics are the classical poem
*Astawdi'u Allah fi Baghdad* (Ibn Zurayq) and the lyrics I fed are CORRECT; the model *sang* two words wrong:

| Time (by ear, approx.) | Where in the lyrics | Correct | Sung |
|---|---|---|---|
| 02:37 (~frame 3925) | end of **[Verse 2]**, line `بِلَا شُكْرٍ عَلَيْهِ فَإِنَّ اللَّهَ يَنْزِعُهُ...` | `عَلَيْهِ` | `عَلِيمْ` |
| 03:24 (~frame 5100) | same two lines, repeated as the last lines of **[Outro]** | `فَإِنَّ` | `بِأَنَّ` |

The same verse (`وَمَنْ غَدَا لَابِسًا ثَوْبَ النَّعِيمِ / بِلَا شُكْرٍ عَلَيْهِ فَإِنَّ اللَّهَ يَنْزِعُهُ...`) appears
twice (end of Verse 2 and in the Outro). The song is 5397 frames (215.9 s); the second error is in the last
~297 frames (~12 s). Times are by-ear estimates (+/- 1-2 s); locate the exact frames yourself.
The case study is in `docs/happy_accidents/`. My hypotheses (unverified): rhyme contamination from the previous
line ending in `النَّعِيمِ` (error 1); plosive /b/ replacing /f/ at the start of the climax (error 2).

## Goal
A new render **as identical as possible to the original** with only those two words sung correctly.
Do NOT change the lyrics' words, style prompt, LoRA, seed or sampler settings for the song as a whole.
Do not touch the other 11 tracks of the batch.

## Exact conditioning text (already recovered and hash-verified)
Two files accompany this prompt: `track02B_lyrics.txt` and `track02B_style.txt`. They were extracted
byte-for-byte from the `--lyrics` / `--request-option style=` arguments recorded by `/usr/bin/time -v` in
`02-...-B_1712905618_time.txt`, and their sha256 equal the manifest's values (**no trailing newline**):
- lyrics: `7bd3b6e1da3aa4e674d728cd24af4a3ffe6e89468b6b5714b543c6310513c46d`
- style : `248af8e769501f2bb565129d781ea33d5672039d908286729d6f319066430b8e`
Facts about them: the **first line of the lyrics is the literal `///***///`** (it was really fed to the model:
it is inside the hash-matched text), and the style already starts with the trigger `arabmaqamrock,` (so
`generate.py` does not prepend anything). Use these files as the single source of truth (copy them into
`prompts/` under new names; never retype them; keep them byte-identical). If the original
`prompts/02-...-B_{lyrics,style}.txt` exist, their sha256 must equal the values above.
Pass them the way `run_one.sh` does (`--lyrics "$(cat file)"`, `--request-option style="$(cat file)"`).

## Integrity checks (from `batch_manifest.json`; verify every one before generating)
| Item | Expected |
|---|---|
| batch input JSON | `../batch_12_variants_backing_vocals.json`, sha256 `73566c1b433485241a8194288aacd827e00aa43fa38d7e28efbf94f543a52483` |
| LoRA AR | `arabmaqamrock-v3-ar.safetensors`, sha256 `3531bb9106d2292eefe58eabe11ec08bb7dddc69554f2b016dc9f13f711fab18` (matches MODEL_CARD v3) |
| LoRA NAR | `arabmaqamrock-v3-nar.safetensors`, sha256 `a7eabcadb22146048bcb5e65d04828ee9454559523ca161bd38c06060deb0cae` (matches MODEL_CARD v3) |
| Main GGUF | `yue2-3b-bf16.gguf`, sha256 `4cf3fdffbaaed2d8e30a3122ac7cd27d0c96f8921805f173da9758c685b3c7d6` |
| VAE GGUF | `yue2-vae-f16.gguf`, sha256 `d4f4a05d8f291ae820cd1e43609da3fa91b56465810091a2b08c3350b751719d` |
| Style / Lyrics | see the previous section |
| Cap | 6750 (n_letters 507, quantile 0.95; 111.1 + 0.3126*507 = 269.6 s -> 270 s -> 6750) |
| GPU | Tesla T4, compute capability 7.5 |
| audio.cpp commit | **null / unknown** (manifest) |
| LoRA checkpoint step | 5000 |
If any hash differs, STOP and tell me which one and what it likely means before running anything.

## Recorded recipe of the original run (from its log)
- `--seed 1712905618`, `semantic_max_tokens=6750` (explicit cap), `cot=off`, `stop_after=audio`
- guidance_scale 1.01, num_inference_steps 8, NAR context 24576, nar_noise generated
- semantic sampling = documented defaults: temperature 1, top_p 0.95, top_k 100, repetition_penalty 1.2,
  penalty_window 50, min_tokens 200 (so no `EXTRA_REQUEST_OPTS`)
- `yue2.attention=flash`; LoRA AR+NAR scale 1.0; CUDA graphs disabled by the runtime on the T4
- Log fingerprints to match in the baseline: `ar.cfg.positive_prefix_tokens 1079`, `negative_prefix_tokens 12`,
  `semantic.tokens 5397`, `semantic.truncated 0`, `vae_decode.latent_frames 5397`, duration ~215.9 s.

## Key facts from the audio.cpp docs/source (verify against the code you actually have)
- `export_semantic=true` or `stop_after=semantic` writes `semantic.json` (with `--out-dir`): a flat JSON array,
  one codec index per frame, **25 frames/s**.
- `semantic_prefix_file` forces the first N frames as history; AR samples from frame N. `semantic_max_tokens`
  must be >= N and counts the whole stream.
- `semantic_min_tokens = semantic_max_tokens = N` renders exactly the given frames with no sampling (NAR + VAE only).
- NAR noise: `std::mt19937(uint32(seed))` + `normal_distribution`, drawn sequentially over `frames x 64`
  (`nar_runtime.cpp`); the AR RNG is separate. `nar_noise_file` can override it. Same tokens + same seed +
  same length + same hardware should reproduce the same audio.
- The docs say a prefix run does NOT reproduce the draws of an uninterrupted run, and that with guidance != 1.0
  (cot=off defaults to 1.01) memory grows with the prefix length.
- The log shows the NAR stage runs the **whole song as one chunk** (`synthesize.chunks 1`), so changing tokens
  in one place may perturb the rendered audio slightly elsewhere. Measure it.
- Fixed cost per CLI call on the T4 is ~4 min (AR init ~68 s, NAR LoRA merge ~117 s, NAR init ~64 s); AR decoding
  is ~24 tokens/s. Consider the audio.cpp server (keeps a session loaded) to amortize this across candidates.

## Hard constraints
- Never overwrite the original outputs; every experiment goes in a new, named dir.
- Keep everything else identical to the recorded recipe, **including the GPU type (a Colab T4) and
  `yue2.attention=flash`**: a different GPU architecture can change float numerics enough to change sampled tokens.
- Report failure honestly. "Cannot be done with this binary/hardware" is a valid result.

## Step 0: Recover the original run
Find the original run folder (WAV, `<name>_<seed>.json` sidecar with `wav_sha256`, `batch_manifest.json`,
`input.json`, `prompts/`, `.log`; if the Colab VM was wiped, look in
`gs://akbar-december-2024-backup/arabmaqamrock/runs/`). Run all the integrity checks above. If the WAV is missing,
say so: the baseline check then relies on the log fingerprints only. List any discrepancy between the files and
the recorded recipe.

## Step 1: Find and check the binary
The manifest records `audio_cpp_commit: null`, so the exact build is unknown. Prefer the very same binary: look for
it on the machine and in the GCS prefix (its `manifest.json` records the ggml commit; `audio.cpp_commit=unknown`
for the 2026-09-22 prebuilts). The log shows `stop_after` in the request trace, so the binary knows at least that
option. Check `export_semantic` and `semantic_prefix_file`: do not assume unknown options error out; test by
rendering a tiny token list with `min=max=N` and confirm (log + output duration = N/25 s) that the AR stage was
skipped. If a rebuild would be needed, tell me BEFORE doing it (a rebuild may change numerics and break
reproduction); if you must, record the commit in `plumbing/audio_cpp.pin`.

## Step 2: Baseline reproduction
Run the original request with the same seed plus `stop_after=semantic` (and `--out-dir`). Success = the log
fingerprints above (1079/12 prefix tokens, 5397 semantic tokens, not truncated). Then render those tokens
(`min=max=5397`, same seed) and compare with the original WAV (sha256 vs the sidecar's `wav_sha256`, then
sample-level diff or, failing that, spectrogram/envelope correlation). Confirm the two errors are present at
~02:37 and ~03:24. If the baseline does not reproduce, report the differences and stop for my decision.

## Step 3: Locate the two lines in token space
frame = seconds x 25. Find word-level boundaries of each bad line by rendering token prefixes
`[0:end_of_window]` (not isolated slices: the NAR conditions on context) and listening/ASR (validate any ASR on
the original first). Pick cut points at natural vocal gaps/breaths. Record `[a, b)` frame ranges for each bad line
and what follows it.

## Step 4: Error 2 first (cheap: only ~300 frames follow it)
Candidates: prefix = original tokens `[:P]` with P a few seconds before the Outro line; `semantic_max_tokens` >= the
original total; vary **only the seed** (16-32 values). Only the Outro's last ~12 s is redrawn, so a tail resample is
the primary route here. Evaluate by rendering `[0:end]` of each candidate and listening to the last 20 s. If I want
the original ending kept, try splicing instead (Step 6) and tell me how the seam sounds.

## Step 5: Error 1
Option A (preferred, keeps the rest of the song): AR-only candidates for the line (prefix = tokens before the
line, `stop_after=semantic`, short cap), seed sweep, optionally a second sweep with slightly lower
`semantic_temperature` (0.8-0.9) for this window only. Pick candidates with the word right and about the same frame
length as the original line, then splice (Step 6).
Option B (fallback): tail resample from the prefix before the line (everything after it, including the second
Chorus and the Outro, will change; fix error 2 afterwards on the new tail).
Low-confidence idea: the same text is sung correctly elsewhere in the song, but in a different musical context, so
swapping tokens between occurrences is unlikely to work; test only if cheap.

## Step 6: Splice and render
Replace original frames `[a, b)` with a candidate segment of the **same length**. If the length differs, say how you
handled the noise offset (e.g. reproduce the original `mt19937` noise stream with a tiny C++ dumper using the same
libstdc++ code path as `nar_runtime.cpp` and pass an aligned `nar_noise_file`). Render the whole spliced stream with
`min=max=N` and the ORIGINAL seed. Verify error 1, then do error 2.
Quantify collateral change: segment-wise spectral distance vs the baseline outside the edited windows (expect small
but nonzero because NAR is a single global chunk). Listen to the seams (clicks, timbre jump, rhythm shift).

## Step 7: Fallback ladder (only if splicing is unacceptable)
a) tail resample from before the bad line; b) full-song seed sweep with the same settings; c) stem-level repair
outside YuE2 (separate stems, crossfade a clean phrase into the original vocal). State how far each departs from
the original.

## Deliverables
1. `experiments.md`: table of every experiment (what changed, paths, result at 02:37, result at 03:24, similarity
   to baseline, wall time, notes).
2. A reproducible script (repo style) that rebuilds the best final WAV from the original recipe + chosen candidate
   tokens.
3. A short report: Step 0-2 findings (hash checks, binary used, did the baseline reproduce, on which GPU), what
   worked, what did not, and your top 3 candidates with timestamps. I decide by ear.

## Working style
State assumptions; ask me about anything unrecoverable. Sequential runs only (parallel runs can run out of memory on
a T4). Log GPU name, binary version and all options for every run.
